﻿# Здесь хранятся записи о незавершённых операциях и правила их безопасного восстановления.

# Оформление заголовка меню в консоли.
# Хранит состояние операции на целевом устройстве. Пароли не записываются.
function Assert-WpmDirectoryChain([string]$Path) {
    $entry = [IO.DirectoryInfo]::new([IO.Path]::GetFullPath($Path))
    while ($null -ne $entry) {
        try {
            $item = Get-Item -LiteralPath $entry.FullName -Force -ErrorAction Stop
            if (-not $item.PSIsContainer -or ($item.Attributes -band [IO.FileAttributes]::ReparsePoint)) {
                throw ('Рабочий каталог или его родитель является ссылкой либо файлом: ' + $entry.FullName)
            }
        } catch [System.Management.Automation.ItemNotFoundException] {
            # Каталог может ещё не существовать, но его родители должны быть безопасны.
        }
        $entry = $entry.Parent
    }
}

function New-WpmWorkDirectoryAcl {
    $admin = [Security.Principal.SecurityIdentifier]::new('S-1-5-32-544')
    $system = [Security.Principal.SecurityIdentifier]::new('S-1-5-18')
    $acl = [Security.AccessControl.DirectorySecurity]::new()
    $acl.SetOwner($admin)
    $acl.SetAccessRuleProtection($true,$false)
    foreach ($identity in @($admin,$system)) {
        $acl.AddAccessRule([Security.AccessControl.FileSystemAccessRule]::new(
            $identity,'FullControl','ContainerInherit,ObjectInherit','None','Allow'))
    }
    return $acl
}

function Assert-WpmWorkAcl([string]$Path) {
    Assert-WpmDirectoryChain $Path
    if ([Environment]::OSVersion.Platform -ne [PlatformID]::Win32NT) { return }
    $acl = Get-Acl -LiteralPath $Path -ErrorAction Stop
    $trusted = @('S-1-5-32-544','S-1-5-18')
    $aclRules = $acl.GetAccessRules($true,$true,[Security.Principal.SecurityIdentifier])
    if (-not $acl.AreAccessRulesProtected -or
        $acl.GetOwner([Security.Principal.SecurityIdentifier]).Value -notin $trusted) {
        throw ('Рабочий каталог не защищён. Проверьте владельца и права каталога: ' + $Path)
    }
    foreach ($rule in $aclRules) {
        if ($rule.AccessControlType -eq 'Allow' -and $rule.IdentityReference.Value -notin $trusted) {
            throw ('Рабочий каталог доступен посторонним: ' + $Path)
        }
    }
}

function Assert-WpmWorkRoot {
    Assert-WpmWorkAcl $Script:WpmWorkRoot
}

function Initialize-WpmWorkDirectory([string]$Path) {
    $root = [IO.Path]::GetFullPath($Script:WpmWorkRoot)
    $directory = [IO.Path]::GetFullPath($Path)
    if ([IO.Path]::GetDirectoryName($directory) -ine $root) { throw 'Недопустимый рабочий каталог.' }
    foreach ($candidate in @($root,$directory)) {
        Assert-WpmDirectoryChain $candidate
        if (-not (Test-Path -LiteralPath $candidate -PathType Container -ErrorAction Stop)) {
            # В Windows владелец и DACL устанавливаются при создании, до появления данных.
            if ([Environment]::OSVersion.Platform -eq [PlatformID]::Win32NT) {
                $acl = New-WpmWorkDirectoryAcl
                if ($PSVersionTable.PSEdition -eq 'Desktop') {
                    [void][IO.Directory]::CreateDirectory($candidate,$acl)
                } else {
                    [void][IO.FileSystemAclExtensions]::CreateDirectory($acl,$candidate)
                }
            } else {
                [void][IO.Directory]::CreateDirectory($candidate)
            }
        }
        Assert-WpmWorkAcl $candidate
    }
}
function Save-TrackedState([hashtable]$State) {
    if ([string]$State.Id -notmatch '^WPM_\d{8}_\d{6}_\d{3}_[a-f0-9]{12}$') {
        throw 'Некорректный идентификатор операции.'
    }
    Initialize-WpmWorkDirectory $Script:OpStateRoot
    $path = Join-Path $Script:OpStateRoot ($State.Id + '.json')
    $tmp = $path + '.' + [guid]::NewGuid().ToString('N') + '.tmp'
    $stream = $null
    try {
        $State.LastUpdated = (Get-Date).ToString('o')
        $bytes = [Text.Encoding]::UTF8.GetBytes(($State | ConvertTo-Json -Depth 7 -ErrorAction Stop))
        $stream = [IO.File]::Open($tmp,[IO.FileMode]::CreateNew,[IO.FileAccess]::Write,[IO.FileShare]::None)
        $stream.Write($bytes,0,$bytes.Length)
        $stream.Flush($true)
        $stream.Dispose()
        $stream = $null
        # После сбоя читатель видит предыдущую или новую полную запись.
        if ([IO.File]::Exists($path)) {
            $item = Get-Item -LiteralPath $path -Force -ErrorAction Stop
            if ($item.Attributes -band [IO.FileAttributes]::ReparsePoint) { throw 'Файл состояния является ссылкой.' }
            [IO.File]::Replace($tmp,$path,[NullString]::Value)
        } else {
            [IO.File]::Move($tmp,$path)
        }
    } finally {
        if ($null -ne $stream) { $stream.Dispose() }
        # Ошибка очистки временного JSON не перекрывает результат операции.
        try {
            if ([IO.File]::Exists($tmp)) { [IO.File]::Delete($tmp) }
        } catch { Write-OperationReport 'ПРЕДУПРЕЖДЕНИЕ' ('Временный файл состояния остался: ' + $tmp) }
    }
}
function Start-TrackedState([string]$Kind,[string]$Archive) {
    $process = Get-Process -Id $PID -ErrorAction Stop
    try { $startTicks = $process.StartTime.ToUniversalTime().Ticks }
    finally { $process.Dispose() }
    $state = @{
        Id=('WPM_' + (Get-Date -Format 'yyyyMMdd_HHmmss_fff') + '_' + [guid]::NewGuid().ToString('N').Substring(0,12));
        Kind=$Kind; Status='Начато'; SourceArchive=$Archive; TargetAccount='';
        CreatedAccount=''; CreatedSid=''; CreatedByTool=$false; AccountCreationPending=$false;
        TargetSid=''; TargetProfile=''; RecoveryReviewed=$false; ImportCompleted=$false;
        StagingPath=''; StagingDisposition=''; StagingPurpose=''; DesktopBackup=''; DesktopBackupSha256='';
        NetworkPartialPath=''; BrowserBackupPath=''; ConfigBackupPath='';
        USMTStarted=$false; USMTFinished=$false; CleanupDone=$false;
        UsmtProcessName=''; UsmtProcessId=0; UsmtProcessStartTicks=0;
        LastError=''; LastUpdated=''; Report=[string]$Script:ReportPath;
        ProcessId=$PID; ProcessStartTicks=$startTicks
    }
    Save-TrackedState $state
    $Script:ActiveOpState=$state
}
function Update-TrackedState([string]$Status,[hashtable]$Fields = @{}) {
    if (-not $Script:ActiveOpState) { return }
    if ($Status) { $Script:ActiveOpState.Status = $Status }
    foreach ($key in $Fields.Keys) { $Script:ActiveOpState[$key] = $Fields[$key] }
    Save-TrackedState $Script:ActiveOpState
}
function Get-TrackedStates([switch]$RequireReadable,[string]$Id = '',[switch]$Legacy) {
    $root = if ($Legacy) { $Script:LegacyOpStateRoot } else { $Script:OpStateRoot }
    if (-not $root) { return }
    Assert-WpmDirectoryChain $root
    if (-not (Test-Path -LiteralPath $root -PathType Container -ErrorAction Stop)) { return }
    if (-not $Legacy) {
        Assert-WpmWorkRoot
        Assert-WpmWorkAcl $root
    }
    $results=@()
    foreach ($file in @(Get-ChildItem -LiteralPath $root -Filter 'WPM_*.json' -File -Force -ErrorAction Stop)) {
        if ($Id -and $file.BaseName -cne $Id) { continue }
        if ($file.BaseName -notmatch '^WPM_\d{8}_\d{6}_\d{3}_[a-f0-9]{12}$') { continue }
        try {
            if ($file.Attributes -band [IO.FileAttributes]::ReparsePoint) { throw 'Файл состояния является ссылкой.' }
            $stream = [IO.File]::Open($file.FullName,[IO.FileMode]::Open,[IO.FileAccess]::Read,
                ([IO.FileShare]::Read -bor [IO.FileShare]::Delete))
            try {
                $item = Read-BoundedArchiveMetadata $stream $stream.Length
            } finally { $stream.Dispose() }
            if ($item -isnot [pscustomobject] -or $item.Id -cne $file.BaseName -or
                $item.Kind -isnot [string] -or $item.Status -isnot [string] -or
                $item.TargetAccount -isnot [string] -or $item.USMTStarted -isnot [bool] -or
                $item.USMTFinished -isnot [bool] -or $item.CreatedByTool -isnot [bool]) {
                throw 'Файл состояния повреждён.'
            }
            $results += $item
        } catch {
            $message = 'Не удалось проверить состояние операции: ' + $file.FullName
            if ($RequireReadable) { throw $message }
            Write-Host $message -ForegroundColor Yellow
        }
    }
    $results | Sort-Object LastUpdated -Descending
}

# Общая блокировка получателя защищает импорт и управляемый откат разных сеансов.
# Сам файл остаётся на месте, а дескриптор освобождается при завершении процесса.
function Enter-ProfileMutationLock {
    Initialize-WpmWorkDirectory $Script:OpStateRoot
    $path = Join-Path $Script:OpStateRoot 'profile-mutation.lock'
    if (Test-Path -LiteralPath $path -ErrorAction Stop) {
        $item = Get-Item -LiteralPath $path -Force -ErrorAction Stop
        if ($item.PSIsContainer -or ($item.Attributes -band [IO.FileAttributes]::ReparsePoint)) {
            throw 'Некорректный файл блокировки импорта.'
        }
    }
    try {
        return [IO.File]::Open($path,[IO.FileMode]::OpenOrCreate,[IO.FileAccess]::ReadWrite,[IO.FileShare]::None)
    } catch {
        throw ('Не удалось получить блокировку. Проверьте, что другой импорт или восстановление завершены. ' + $_.Exception.Message)
    }
}

# PID и время запуска отличают процесс USMT от другого процесса, получившего тот же PID.
function Assert-TrackedUsmtStopped([object]$State) {
    $name = ''
    $childId = 0
    $startedAt = 0L
    if ($State -is [System.Collections.IDictionary]) {
        $name = [string]$State['UsmtProcessName']
        $childId = [int]$State['UsmtProcessId']
        $startedAt = [long]$State['UsmtProcessStartTicks']
        $hasProcessRecord = $State.Contains('UsmtProcessName')
    } else {
        $hasProcessRecord = $null -ne $State.PSObject.Properties['UsmtProcessName']
        if ($hasProcessRecord) {
            $name = [string]$State.UsmtProcessName
            $childId = [int]$State.UsmtProcessId
            $startedAt = [long]$State.UsmtProcessStartTicks
        }
    }
    if (-not $hasProcessRecord -and $State.PSObject.Properties['USMTStarted'] -and $State.USMTStarted -and -not $State.USMTFinished) {
        # Старые журналы не хранят PID USMT. Для них проверяем имя процесса.
        $name = if ($State.Kind -eq 'Импорт') { 'LoadState' } elseif ($State.Kind -eq 'Экспорт') { 'ScanState' }
    }
    if (-not $name) { return }
    if ($name -notin @('ScanState','LoadState','UsmtUtils')) { throw 'Некорректное имя процесса USMT в журнале.' }
    $running = @(Get-Process -Name $name -ErrorAction SilentlyContinue)
    try {
        foreach ($process in $running) {
            if ($childId -gt 0 -and $startedAt -gt 0) {
                if ($process.Id -ne $childId) { continue }
                try {
                    if ($process.StartTime.ToUniversalTime().Ticks -ne $startedAt) { continue }
                } catch [InvalidOperationException] {
                    if ($process.HasExited) { continue }
                    throw
                }
            }
            if (-not $process.HasExited) { throw 'USMT ещё работает. Очистка и повтор операции пока недоступны.' }
        }
    } finally {
        foreach ($process in $running) { $process.Dispose() }
    }
}

function Assert-TrackedOperationStopped([object]$State) {
    Assert-TrackedUsmtStopped $State
    if (-not $State.PSObject.Properties['ProcessId'] -or -not $State.PSObject.Properties['ProcessStartTicks'] -or
        [int]$State.ProcessId -le 0) { return }
    if ([int]$State.ProcessId -eq $PID -and (-not $Script:ActiveOpState -or $Script:ActiveOpState.Id -ne $State.Id)) { return }
    $process = Get-Process -Id ([int]$State.ProcessId) -ErrorAction SilentlyContinue
    if ($null -eq $process) { return }
    try {
        if ($process.StartTime.ToUniversalTime().Ticks -eq [long]$State.ProcessStartTicks) {
            throw 'Операция выполняется. Восстановление и очистка пока недоступны.'
        }
    } finally { $process.Dispose() }
}

function Assert-OperationTreeHasNoReparsePoint([string]$Path) {
    $pending = [Collections.Generic.Stack[string]]::new()
    $pending.Push($Path)
    $activity = 'Проверка дерева временного каталога'
    $checked = 0L
    $refresh = [Diagnostics.Stopwatch]::StartNew()
    try {
        Write-Progress -Id 10 -Activity $activity -Status 'Начат обход файлов и папок' -PercentComplete -1
        while ($pending.Count -gt 0) {
            $item = Get-Item -LiteralPath ($pending.Pop()) -Force -ErrorAction Stop
            if ($item.Attributes -band [IO.FileAttributes]::ReparsePoint) {
                throw ('Зарегистрированный путь содержит ссылку: ' + $item.FullName)
            }
            $checked++
            if ($refresh.ElapsedMilliseconds -ge 350) {
                Write-Progress -Id 10 -Activity $activity -Status ('Проверено объектов: ' + $checked) -PercentComplete -1
                $refresh.Restart()
            }
            if ($item.PSIsContainer) {
                foreach ($child in @(Get-ChildItem -LiteralPath $item.FullName -Force -ErrorAction Stop)) {
                    $pending.Push($child.FullName)
                }
            }
        }
    } finally {
        Write-Progress -Id 10 -Activity $activity -Completed
    }
    return $checked
}
# Разрешена очистка только собственных временных каталогов под ProgramData.
function Assert-SafeStaging([string]$Candidate, [switch]$ReportTree) {
    if (-not $Candidate) { throw 'Временная папка не указана.' }
    $base = [IO.Path]::GetFullPath($Script:WpmStagingRoot)
    $full = [IO.Path]::GetFullPath($Candidate)
    if ([IO.Path]::GetDirectoryName($full) -ine $base -or
        [IO.Path]::GetFileName($full) -notmatch '^(ImportCache|Export)_\d{8}_\d{6}_\d{3}_[a-f0-9]{8}$') {
        throw 'Неверный путь временного каталога. Очистка запрещена.'
    }
    Assert-WpmWorkRoot
    Assert-WpmWorkAcl $base
    Assert-WpmDirectoryChain $full
    if (Test-Path -LiteralPath $full -ErrorAction Stop) {
        $checked = Assert-OperationTreeHasNoReparsePoint $full
        if ($ReportTree) {
            Write-OperationReport 'ПРОВЕРКА' ('Перед очисткой проверено объектов во временном каталоге: ' + $checked)
        }
    }
    return $full
}
function Clear-TrackedStaging([hashtable]$State,[bool]$Ask = $false) {
    if (-not $State.StagingPath) { return $true }
    $safe=Assert-SafeStaging ([string]$State.StagingPath) -ReportTree:(-not $Ask)
    if ($Ask -and -not (Confirm ('Удалить только временный каталог ' + $safe + ' ?'))) {
        Write-OperationReport 'ОТМЕНА' 'Удаление временного каталога не подтверждено.'
        return $false
    }
    try {
        Assert-TrackedUsmtStopped $State
        if ($Ask) { $safe = Assert-SafeStaging ([string]$State.StagingPath) -ReportTree }
        if (Test-Path -LiteralPath $safe -ErrorAction Stop) { Remove-Item -LiteralPath $safe -Recurse -Force -ErrorAction Stop }
        $State.CleanupDone=$true; $State.StagingDisposition='Временная копия удалена'
        Save-TrackedState $State
        Write-OperationReport 'ОЧИСТКА' ('Удалён временный каталог: ' + $safe)
        return $true
    } catch {
        $State.CleanupDone=$false; $State.StagingDisposition='Ошибка удаления: '+$_.Exception.Message
        Save-TrackedState $State
        Write-OperationReport 'ПРЕДУПРЕЖДЕНИЕ' ('Не удалось очистить временный каталог: ' + $safe + '; ' + $_.Exception.Message)
        return $false
    }
}

# Меню для незавершённых импортов: исходные профили и пользовательские данные не удаляются.
# Удалять сетевую недокопированную папку можно только внутри места публикации,
# которое записано в исходном состоянии операции.
function Assert-RegularNetworkPartial([string]$Path) {
    $file = Get-Item -LiteralPath $Path -Force -ErrorAction Stop
    if ($file -isnot [IO.FileInfo] -or ($file.Attributes -band [IO.FileAttributes]::ReparsePoint)) {
        throw 'Незавершённый архив должен быть обычным файлом. Очистка запрещена.'
    }
}

function Clear-NetworkPartial([hashtable]$State,[bool]$Ask = $true) {
    $target=[string]$State.NetworkPartialPath
    $published=[string]$State.SourceArchive
    if ($State.Kind -ne 'Экспорт' -or -not $target -or -not $published) { throw 'Нет сетевого временного каталога для очистки.' }
    $final=[IO.Path]::GetFullPath($published).TrimEnd('\')
    $temp=[IO.Path]::GetFullPath($target).TrimEnd('\')
    $parent=[IO.Path]::GetDirectoryName($final)
    $finalName = [IO.Path]::GetFileName($final)
    $partialPattern = '^' + [regex]::Escape($finalName) + '\.partial_[a-f0-9]{8}$'
    $knownArchive = $finalName.EndsWith('.zip', [StringComparison]::OrdinalIgnoreCase) -or
        $finalName.EndsWith('.wpm.pgp', [StringComparison]::OrdinalIgnoreCase)
    if (-not $knownArchive -or
        [IO.Path]::GetDirectoryName($temp) -ine $parent -or
        [IO.Path]::GetFileName($temp) -notmatch $partialPattern) {
        throw 'Подозрительное имя незавершённого архива. Очистка запрещена.'
    }
    Assert-WpmDirectoryChain $parent
    if (Test-Path -LiteralPath $temp -ErrorAction Stop) {
        Assert-RegularNetworkPartial $temp
    }
    if ($Ask -and -not (Confirm ('Удалить незавершённую копию ' + $temp + ' ?'))) { return $false }
    Assert-WpmDirectoryChain $parent
    if (Test-Path -LiteralPath $temp -ErrorAction Stop) {
        Assert-RegularNetworkPartial $temp
        [IO.File]::Delete($temp)
    }
    $State.NetworkPartialPath=''
    Save-TrackedState $State
    Write-OperationReport 'ОЧИСТКА' ('Удалена незавершённая копия: ' + $temp)
    Write-Host 'Незавершённая копия удалена.' -ForegroundColor Green
    return $true
}

# Показываем операции, чтобы пользователь выбрал одну запись или вернулся назад.
function Select-RecoveryRecord {
    $items = @(
        foreach ($record in @(Get-TrackedStates)) { [pscustomobject]@{State=$record;Legacy=$false} }
        foreach ($record in @(Get-TrackedStates -Legacy)) { [pscustomobject]@{State=$record;Legacy=$true} }
    )
    if ($items.Count -eq 0) { Write-Host 'Операций пока нет.'; return }
    for ($i=0; $i -lt $items.Count; $i++) {
        $item = $items[$i]
        $label = if ($item.Legacy) { 'Старая запись, только просмотр' } else { $item.State.Kind }
        $status = [string]$item.State.Status -replace '[\x00-\x1F\x7F-\x9F]', '?'
        $when = if ($item.State.PSObject.Properties['LastUpdated']) {
            [string]$item.State.LastUpdated -replace '[\x00-\x1F\x7F-\x9F]', '?'
        } else { '' }
        Write-Host ('{0}. {1} | {2} | {3}' -f ($i+1),$label,$status,$when)
    }
    Write-Host '0. Назад'
    $index=Choice 'Номер операции' $items.Count
    if ($index -eq 0) { return }
    return $items[$index-1]
}

# Записи старого формата разрешено открывать только для просмотра.
function Show-LegacyRecoveryRecord($State) {
    foreach ($field in @('Kind','Status','LastUpdated','SourceArchive','TargetAccount','StagingPath','NetworkPartialPath','DesktopBackup','LastError')) {
        if ($State.PSObject.Properties[$field] -and $State.$field) {
            Write-Host ($field + ': ' + ([string]$State.$field -replace '[\x00-\x1F\x7F-\x9F]', '?'))
        }
    }
    Write-Host 'Старая запись доступна для просмотра. Проверьте перечисленные данные средствами Windows.'
}

function Read-RecoveryAction($State) {
    Write-Host ('Результат: ' + $State.Status)
    Write-Host ('Исходный архив: ' + $State.SourceArchive)
    Write-Host ('Целевая учётная запись: ' + $State.TargetAccount)
    Write-Host ('Профиль: ' + $State.TargetProfile)
    Write-Host ('Создана программой: ' + $State.CreatedByTool)
    Write-Host ('Временная копия: ' + $State.StagingPath)
    Write-Host ('Незавершённая публикация архива: ' + $State.NetworkPartialPath)
    Write-Host ('Резерв значков: ' + $State.DesktopBackup)
    foreach ($entry in @(@('BrowserBackupPath','Резерв браузеров'),@('ConfigBackupPath','Резерв настроек'))) {
        if ($State.PSObject.Properties[$entry[0]] -and $State.($entry[0])) {
            Write-Host ($entry[1] + ': ' + $State.($entry[0]))
        }
    }
    if ($State.LastError) { Write-Host ('Ошибка: ' + $State.LastError) -ForegroundColor Yellow }
    Write-Host 'Перед повторным импортом проверьте, что учётная запись назначения и её каталог не содержат данных.'
    Write-Host '1. Удалить зарегистрированную временную копию'
    Write-Host '2. Удалить только созданную программой локальную учётную запись без профиля'
    Write-Host '3. Восстановить прежние параметры значков'
    Write-Host '4. Удалить незавершённую копию архива'
    Write-Host '5. Подтвердить возможность повторного импорта'
    $canRetryPersonalFiles = Test-PersonalFilesRetryAvailable $State
    if ($canRetryPersonalFiles) {
        Write-Host '6. Повторить восстановление личных файлов'
    }
    Write-Host '0. Назад'
    $maximum = if ($canRetryPersonalFiles) { 6 } else { 5 }
    return (Choice 'Выберите действие' $maximum)
}

# Повторно проверяем SID и отсутствие профиля прямо перед удалением пустой учётной записи.
function Remove-RecoveryAccount($State, [hashtable]$Changes) {
    if ($State.Kind -ne 'Импорт' -or -not $State.CreatedByTool -or -not $State.CreatedAccount -or
        -not $State.CreatedSid -or $State.USMTStarted) {
        throw 'Допускается удаление только подтверждённой учётной записи до запуска LoadState.'
    }
    $computer,$name = [string]$State.CreatedAccount -split '\\',2
    if ($computer -ine $env:COMPUTERNAME -or -not $name) { throw 'Учётная запись не локальная.' }
    $account = Get-ImportLocalUser $name
    if (-not $account -or $account.SID.Value -ne [string]$State.CreatedSid) {
        throw 'Локальный пользователь отсутствует или его SID уже отличается от зарегистрированного.'
    }
    Assert-ImportProfileUnused $account.SID.Value $account.Name
    if (-not (Confirm ('Удалить только пустую учётную запись ' + $State.CreatedAccount + ' ?'))) { return $false }
    if (-not (Confirm 'Повторное подтверждение удаления учётной записи')) { return $false }
    $account = Get-ImportLocalUser $name
    if (-not $account -or $account.SID.Value -ne [string]$State.CreatedSid) {
        throw 'Учётная запись изменилась после подтверждения.'
    }
    Assert-ImportProfileUnused $account.SID.Value $account.Name
    Remove-LocalUser -SID $account.SID -ErrorAction Stop
    $Changes.Status = 'Пустая учётная запись удалена по подтверждению'
    $Changes.CreatedByTool = $false
    Save-TrackedState $Changes
    Write-Host 'Пустая учётная запись удалена.' -ForegroundColor Green
    return $true
}

# Сверяем идентификатор учётной записи с тем, который был сохранён при импорте.
function Resolve-RecoveryTarget($State) {
    $recordedSid = if ($State.PSObject.Properties['TargetSid']) { [string]$State.TargetSid } else { [string]$State.CreatedSid }
    $identity = [pscustomobject]@{SourceAccount=$State.TargetAccount;SourceSid=$recordedSid;AccountType='Domain'}
    $target = Resolve-ImportTarget $identity $State.TargetAccount
    if ($recordedSid -and $target.Sid -and $recordedSid -ne $target.Sid) {
        throw 'SID назначения отличается от сохранённого. Проверьте учётную запись вручную.'
    }
    return $target
}

# Пользователь сверяет профиль и подтверждает повторную попытку. Запоминаем только подтверждённый выбор.
function Confirm-ImportRetry($State, [hashtable]$Changes) {
    $pending = $State.PSObject.Properties['AccountCreationPending'] -and $State.AccountCreationPending -eq $true
    if ($State.Kind -ne 'Импорт' -or -not $State.TargetAccount -or (-not $State.USMTStarted -and -not $pending)) {
        throw 'Нет незавершённой записи, требующей проверки перед повторным импортом.'
    }
    if ($State.PSObject.Properties['RecoveryReviewed'] -and $State.RecoveryReviewed -eq $true) {
        Write-Host 'Возможность повторного импорта уже подтверждена.'
        return $false
    }
    $target = Resolve-RecoveryTarget $State
    $possibleLocalName = if ($target.Local) { $target.Name } else { '' }
    Assert-ImportProfileUnused $target.Sid $possibleLocalName
    if (-not (Confirm ('Разрешить повторный импорт для ' + $State.TargetAccount + ' после ручной проверки?'))) { return $false }
    Assert-ImportProfileUnused $target.Sid $possibleLocalName
    $Changes.RecoveryReviewed = $true
    Save-TrackedState $Changes
    Write-Host 'Проверка записана. Импорт можно заново запустить через главное меню.' -ForegroundColor Green
    return $true
}

function Test-PersonalFilesRetryAvailable($State) {
    return ($State.Kind -eq 'Импорт' -and $State.USMTFinished -and
        $State.PSObject.Properties['PersonalFilesPending'] -and $State.PersonalFilesPending)
}

# Используем те же границы архива, что при импорте, и привязываем его к прежнему SID.
function Restore-TrackedPersonalFiles([string]$Archive, $Metadata, $State) {
    if ($State.PersonalMetadataHash -ne (Get-ExactFileSha256 (Join-Path $Archive 'metadata.json')) -or
        $State.PersonalManifestHash -ne (Get-ExactFileSha256 (Join-Path $Archive 'Validation\extras.jsonl'))) {
        throw 'Выбранный архив отличается от архива исходного импорта.'
    }
    $approved = Test-ExtrasManifest $Archive $Metadata
    Assert-PersonalFilesInventory $Metadata $approved
    $personalCount = @($approved.Keys -like 'UserFiles\*').Count
    Write-OperationReport 'ПРОВЕРКА' ('Подтверждён исходный архив, личных файлов в перечне: ' + $personalCount)
    $target = Get-TargetUserProfile $State.TargetAccount
    if ($target.Sid -ne $State.TargetSid -or ($State.TargetProfile -and $target.Path -ine $State.TargetProfile)) {
        throw 'Профиль назначения изменился после импорта.'
    }
    Update-TrackedState 'Выполняется повтор личных файлов' @{
        TargetAccount=$State.TargetAccount; TargetSid=$target.Sid; TargetProfile=$target.Path
    }
    return (Restore-PersonalFiles $Archive $target $Metadata $approved)
}

function Invoke-PersonalFilesRetry($State, [hashtable]$Changes) {
    if (-not (Test-PersonalFilesRetryAvailable $State)) {
        Write-OperationReport 'ВОССТАНОВЛЕНИЕ' 'В записи нет личных файлов, ожидающих повтора.'
        return $false
    }
    if (-not (Confirm ('Восстановить личные файлы для ' + $State.TargetAccount + '?'))) {
        Write-OperationReport 'ОТМЕНА' 'Повтор личных файлов не подтверждён.'
        return $false
    }
    $archive = [string]$State.SourceArchive
    if (Test-Path -LiteralPath $archive) {
        Write-Host ('1. Использовать архив из журнала: ' + $archive)
        Write-Host '2. Выбрать другую копию архива'
        Write-Host '0. Назад'
        switch (Choice 'Выберите архив' 2) {
            0 { return $false }
            2 { $archive = Select-Archive }
        }
    } else {
        Write-Host 'Исходный архив не найден. Выберите его из другой папки.'
        $archive = Select-Archive
    }
    if (-not $archive) { return $false }
    $archiveOrigin = if ($archive -ieq $State.SourceArchive) { 'архив из записи' } else { 'другая копия архива' }
    Write-OperationReport 'ВОССТАНОВЛЕНИЕ' ('Для повтора выбран источник: ' + $archiveOrigin)
    # Проверка обоих SHA-256 выполняется и при выборе другой копии.
    # При ошибке прежний путь в журнале сохраняется.
    try { $complete = Do-Import -ArchiveOverride $archive -PersonalRetry $State }
    finally { $Script:ActiveOpState = $null }
    $Changes.SourceArchive = [IO.Path]::GetFullPath($archive)
    if (-not $complete) {
        Save-TrackedState $Changes
        Write-Host 'Остались невосстановленные личные файлы. Причины указаны в отчёте.' -ForegroundColor Yellow
        Finish-OperationReport 'ЛИЧНЫЕ ФАЙЛЫ ВОССТАНОВЛЕНЫ НЕ ПОЛНОСТЬЮ'
        return $false
    }
    $Changes.PersonalFilesPending = $false
    # Успех повтора меняет итог импорта, только если ранее завершились все остальные этапы.
    # При незавершённом импорте сохраняем его статус и ошибку.
    if (-not $Changes.ContainsKey('ImportCompleted') -or $Changes.ImportCompleted) {
        $Changes.Status = if ($Changes['PersonalSourceIncomplete']) { 'Файлы из архива восстановлены, при экспорте были пропуски' }
            else { 'Личные файлы восстановлены, ожидает приёмки' }
    }
    Save-TrackedState $Changes
    return $true
}

# Сначала берём блокировку, затем заново читаем состояние. Другая операция могла изменить его, пока меню было открыто.
function Invoke-TrackedRecovery([string]$Id, [int]$Action) {
    $actions = @{
        1 = 'Очистка временного каталога'
        2 = 'Удаление созданной программой пустой учётной записи'
        3 = 'Откат параметров значков'
        4 = 'Очистка незавершённой копии'
        5 = 'Подтверждение повторного импорта'
        6 = 'Повтор восстановления личных файлов'
    }
    $lock = $null
    try {
        Start-OperationReport 'ВОССТАНОВЛЕНИЕ'
        $actionName = $actions[$Action]
        if (-not $actionName) { throw 'Неизвестное действие восстановления.' }
        Write-OperationReport 'ДЕЙСТВИЕ' ('Операция ' + $Id + ', пункт ' + $Action + ', ' + $actionName)
        Advance-OperationStage 'Чтение записи операции и проверка процессов'
        $lock = Enter-ProfileMutationLock
        $state = Get-TrackedStates -RequireReadable -Id $Id
        if (-not $state) { throw 'Запись выбранной операции больше недоступна.' }
        $personalPending = $state.PSObject.Properties['PersonalFilesPending'] -and $state.PersonalFilesPending
        Write-OperationReport 'СОСТОЯНИЕ' ("Операция: {0}, состояние: {1}, USMT запущен: {2}, USMT завершён: {3}, личные файлы требуют повтора: {4}." -f $state.Kind,$state.Status,$state.USMTStarted,$state.USMTFinished,$personalPending)
        Assert-TrackedOperationStopped $state
        Advance-OperationStage $actionName
        $changes = @{}
        foreach ($property in $state.PSObject.Properties) { $changes[$property.Name] = $property.Value }
        if (Invoke-RecoveryAction $Action $state $changes) {
            Write-OperationReport 'ВОССТАНОВЛЕНИЕ' ('Действие выполнено. Состояние исходной записи: ' + $changes.Status)
            Finish-OperationReport 'УСПЕШНО'
        } elseif ($Script:ReportPath) {
            Write-OperationReport 'ВОССТАНОВЛЕНИЕ' 'Действие не завершено. Проверьте условие или подтверждение выше.'
        }
    } catch [OperationCanceledException] {
        Write-OperationReport 'ОТМЕНА' $_.Exception.Message
        Finish-OperationReport 'ОТМЕНЕНО'
    } catch {
        $Script:HadFailures = $true
        Write-OperationReport 'ОШИБКА' $_.Exception.Message
        Write-DiagnosticFailure $_ 'Восстановление состояния'
        Finish-OperationReport 'СБОЙ ВОССТАНОВЛЕНИЯ'
        Write-Host ('Действие восстановления не выполнено: ' + $_.Exception.Message) -ForegroundColor Red
    } finally {
        if ($null -ne $lock) { $lock.Dispose() }
        if ($Script:ReportPath) { Finish-OperationReport 'ОТМЕНЕНО / НЕ ЗАВЕРШЕНО' }
    }
}

function Invoke-RecoveryAction([int]$Action, $State, [hashtable]$Changes) {
    switch ($Action) {
        1 {
            if (-not $State.StagingPath -or $State.CleanupDone) {
                Write-Host 'Временной копии нет.'
                Write-OperationReport 'ВОССТАНОВЛЕНИЕ' 'Временной копии нет.'
                return $false
            }
            return (Clear-TrackedStaging $Changes $true)
        }
        2 { return (Remove-RecoveryAccount $State $Changes) }
        3 {
            if (-not $State.DesktopBackup) {
                Write-Host 'Резервной копии значков нет.'
                Write-OperationReport 'ВОССТАНОВЛЕНИЕ' 'Резервной копии значков нет.'
                return $false
            }
            if (-not $State.PSObject.Properties['DesktopBackupSha256'] -or -not $State.DesktopBackupSha256) {
                throw 'Для резервной копии отсутствует зарегистрированная контрольная сумма.'
            }
            return (Restore-PreviousDesktopLayout ([string]$State.DesktopBackup) ([string]$State.DesktopBackupSha256))
        }
        4 {
            if (-not $State.NetworkPartialPath) {
                Write-Host 'Незавершённой копии нет.'
                Write-OperationReport 'ВОССТАНОВЛЕНИЕ' 'Незавершённой копии нет.'
                return $false
            }
            return (Clear-NetworkPartial $Changes)
        }
        5 { return (Confirm-ImportRetry $State $Changes) }
        6 { return (Invoke-PersonalFilesRetry $State $Changes) }
    }
}

function Show-RecoveryMenu {
    Title 'СОСТОЯНИЕ ОПЕРАЦИЙ И УПРАВЛЯЕМАЯ ОЧИСТКА'
    $selection = Select-RecoveryRecord
    if (-not $selection) { return }
    $state = $selection.State
    Title ('ОПЕРАЦИЯ ' + $state.Id)
    if ($selection.Legacy) {
        Show-LegacyRecoveryRecord $state
        return
    }
    $action = Read-RecoveryAction $state
    if ($action -ne 0) { Invoke-TrackedRecovery $state.Id $action }
}
